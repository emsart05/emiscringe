from termcolor import *
from colorama import *

init()

playerName = ''
playerAge = ''
gender = ''

