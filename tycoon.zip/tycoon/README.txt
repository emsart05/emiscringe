main.py 
This is an unfinished tycoon game where you can pick a job, go to shcool
to get a better job, earn money, eat, etc. Its pretty lengthy, at least
it feels lengthy to me now because I'm a beginner. But I started something
similar so I was working with something that isn't so cluttered. The
file I'm referring to is:

newmain.py
This one it still being worked on and will likely be updated over time.
It isn't the exact same as main.py, however they are very similar and
share some functions. I will list the files meant for each game below:

Files for main.py:
functions.py
classes.py
obj.py
dialogue.py

Files for newmain.py:
func.py
things.py

tycoon.py was the original files from when I was trying to do everything
on one file. Eventually there was too much code so I moved some stuff to
new files and tried to clean up.

Run the file from command prompt with the python command (you must have python 3 installed)